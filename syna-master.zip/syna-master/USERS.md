* [Okkur Labs](https://about.okkur.org)
* [TXTDirect](https://about.txtdirect.org)
* [Rekkur Solutions](https://about.rekkur.com)
* [nzt.capital](https://about.nzt.capital)
