+++
fragment = "content"
#disabled = true
date = "2017-10-05"
weight = 100
#background = ""

title = "About Syna"
#subtitle = ""
+++

Open Source Theme from Okkur for your next project.

Syna is based on the awesome work by digitalcraftsman with his Hugo Agency Theme.

The Hugo Agency Theme was based on the work of David Miller with his Startupbootstrap Agency Theme.

**Provided with <3 by Okkur Labs**

---

To actually test out the full single page some Lorem Ipsum:

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur a lorem urna. Quisque in neque malesuada, sollicitudin nunc porttitor, ornare est. Praesent ante enim, bibendum sed hendrerit et, iaculis laoreet felis. Morbi efficitur dui sit amet orci porttitor, nec tincidunt turpis elementum. Suspendisse rutrum, mi ac sollicitudin blandit, eros sem tincidunt enim, vitae feugiat turpis eros ut diam. Nunc hendrerit, nibh vitae dignissim pretium, magna nulla lacinia massa, et interdum lacus purus ultricies lacus. Nulla tincidunt quis lacus in posuere. Integer urna lorem, ultricies ut est vel, rhoncus euismod metus. Vestibulum luctus maximus massa, ut egestas est iaculis in. Nunc nisi dolor, sodales et imperdiet ut, lacinia ac justo. Phasellus ultrices risus cursus maximus lobortis. Vestibulum sagittis elementum dignissim. Suspendisse iaculis venenatis nisl, sed bibendum urna. Aliquam quis pellentesque tortor. Sed sed cursus nisl. Aenean eu lorem condimentum, feugiat mauris vitae, hendrerit tellus.

Morbi ac sapien at risus volutpat tincidunt. Sed vel lobortis nisl. Sed mattis facilisis dui quis luctus. Aliquam bibendum venenatis tellus, non interdum nunc convallis in. Sed elementum aliquam tortor, vel consectetur sem sollicitudin sit amet. Nullam in elit turpis. Phasellus sagittis lacus massa, eu porta erat dapibus a. Phasellus placerat, nisi nec molestie accumsan, elit ex rutrum augue, ac pulvinar nulla nisl id velit. Pellentesque sapien dolor, tempus vitae elementum in, gravida ac arcu. Morbi facilisis, mi eget fringilla posuere, lorem ipsum euismod ex, id consequat lacus nisl ac tortor. Vivamus pulvinar dui non arcu lacinia faucibus. Vestibulum sapien leo, pretium in ligula et, aliquet mattis augue. Vestibulum tristique mi ultrices suscipit placerat. Nunc vehicula volutpat tellus sed fringilla.

Curabitur ipsum ipsum, malesuada at tempus sed, pretium vulputate nunc. Praesent nec lectus ut mauris cursus hendrerit a vitae risus. Aliquam sodales lorem nisl, ut euismod dolor interdum ac. Vivamus facilisis justo vulputate augue finibus imperdiet. Aenean sem magna, tempus id orci eu, sodales pulvinar metus. Nullam pharetra ornare est. Vestibulum aliquet turpis et porttitor euismod. Nulla vitae orci orci. Suspendisse fringilla faucibus blandit. Nulla suscipit nulla ut massa elementum sollicitudin. Vivamus ultrices ipsum arcu, in vestibulum erat aliquam quis. Suspendisse eget mauris tellus. Maecenas euismod blandit odio, sed pellentesque orci mollis eget. Sed eget magna eu justo mollis hendrerit.

Suspendisse molestie, tellus quis finibus facilisis, nulla neque euismod mi, at aliquet lectus arcu ac neque. Proin lacus augue, porttitor in odio vitae, sollicitudin laoreet mi. Donec posuere hendrerit augue hendrerit ornare. Duis vestibulum, nisl sit amet cursus lobortis, felis sapien consequat augue, et accumsan eros ligula id nisl. Praesent iaculis fringilla molestie. Sed consequat nec mi vel venenatis. Nunc felis dui, bibendum ac laoreet pretium, cursus ut orci. Nullam risus nulla, tempus ut bibendum quis, consectetur in risus.

Etiam eget metus elit. Praesent turpis mi, malesuada nec libero a, cursus varius leo. In malesuada gravida est, nec maximus turpis posuere eu. Proin rutrum mattis lectus. Ut mi elit, tincidunt ut aliquet consequat, facilisis vitae arcu. Proin ut massa auctor, imperdiet sem ac, varius justo. Integer porta tellus quis eros sollicitudin mollis. Donec nulla sem, porttitor et velit vitae, tincidunt congue erat. Vivamus urna libero, viverra non pharetra eu, bibendum id arcu. In fermentum bibendum purus, vitae pharetra ipsum gravida quis. Nunc vitae congue diam. Maecenas pharetra orci vel magna fermentum, vitae auctor sapien consectetur. Nunc tempor erat vel nisi ullamcorper mollis. Sed et lectus accumsan, pharetra nunc scelerisque, finibus leo. Sed tempor eros nec nunc porta sodales.
