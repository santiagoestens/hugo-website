+++
title = "Configurable"
weight = 20

[asset]
  icon = "fas fa-cubes"
+++

High flexibility to easily configure navigation, sections or whole pages
