+++
title = "hero"
fragment = "content"
weight = 100
+++

Different alignments for hero fragment
