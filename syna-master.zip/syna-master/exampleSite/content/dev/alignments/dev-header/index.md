+++
title = "header"
fragment = "content"
weight = 100
+++

Different alignments for header fragment
