+++
weight = 30

title = "Enterprise plan"
# subtitle = ""

price = "Custom"
# highlight = true

button_text = "Contact us"
button_url = "#"

[[features]]
  text = "**Basic** feature"
  icon = "fas fa-check"

[[features]]
  text = "**Premium** feature"
  icon = "fas fa-check"

[[features]]
  text = "**Email** support"
  icon = "fas fa-check"

[[features]]
  text = "**Chat** support"
  icon = "fas fa-check"

[[features]]
  text = "**Additional enterprise stuff**"
  icon = "fas fa-check"
+++
