+++
title = "graph"
fragment = "content"
weight = 100
+++

Different alignments for graph fragment
