+++
title = "Tiny Gopher 4"
weight = 30
date = "2017-10-17"

position = "Gopherineer"
lives_in = "[Iceland](https://www.google.com/maps/place/Iceland/)"
scope = [
  "Gopherineering for various tasks",
  "Contributor for [Goper Team A](#)",
  "Gopher Community Member"
]

[asset]
  image = "tinygopher.png"
+++

Really tiny Gopher

Some more text to showcase the capabilities:
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Curabitur a lorem urna.
Quisque in neque malesuada, sollicitudin nunc porttitor, ornare est.
Praesent ante enim, bibendum sed hendrerit et, iaculis laoreet felis.
Morbi efficitur dui sit amet orci porttitor, nec tincidunt turpis elementum.
