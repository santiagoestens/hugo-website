+++
title = "Huge Gopher"
weight = 0
date = "2017-10-17"

position = "Lead Gopherineer"
reports_to = "CTO"
lives_in = "[Munich, Germany](https://www.google.com/maps/place/Munich,+Germany/)"
scope = [
  "UX for [Food Dashboard](#)",
  "Maintainer for [Goper Team A](#)",
  "Gopher [Community Administration](#)"
]

[[icons]]
  icon = "fab fa-linkedin-in"
  text = "Linkedin"
  url = "#"

[asset]
  image = "hugegopher.png"
+++

Hugely huge Gopher

Some more text to showcase the capabilities:
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Curabitur a lorem urna.
Quisque in neque malesuada, sollicitudin nunc porttitor, ornare est.
Praesent ante enim, bibendum sed hendrerit et, iaculis laoreet felis.
Morbi efficitur dui sit amet orci porttitor, nec tincidunt turpis elementum.
