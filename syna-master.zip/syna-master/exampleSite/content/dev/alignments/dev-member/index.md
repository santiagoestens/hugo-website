+++
title = "member"
fragment = "content"
weight = 100
+++

Different alignments for member fragment
