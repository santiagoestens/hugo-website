+++
title = "contact"
fragment = "content"
weight = 100
+++

Different alignments for contact fragment
