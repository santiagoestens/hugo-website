+++
title = "Column 2"
weight = 20

[asset]
  image = "go.svg"
  #url = "#"
+++

Showcasing descriptions for column based items
Some more text to showcase the description capabilities:
Lorem ipsum dolor sit amet, consectetur adipiscing elit.
Curabitur a lorem urna.
