+++
title = "footer"
fragment = "content"
weight = 100
+++

Different alignments for footer fragment
