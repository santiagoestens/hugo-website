+++
date = "2018-07-06"
fragment = "list"
weight = 100

#count = 10 # Default value is 10
#section = "" # Default value is current section
#summary = false # Default value is true
#read_more = true # Default value is empty (empty: show when content is truncated, false to never show, true to always show)
#tiled = true # Default value is false
display_date = true # Default is false

#subsections = true # Default to true. Shows subsection branch pages
#subsection_leaves = true # Default to false. Shows subsection leaf pages
+++
