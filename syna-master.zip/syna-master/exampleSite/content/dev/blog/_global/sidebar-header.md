+++
fragment = "header"
slot = "index/sidebar"
weight = 10

title = "Recent pages"
title_align = "left"
padding = "pb-2" # Experimental. May be removed without notice
+++
