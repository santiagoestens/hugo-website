+++
fragment = "list"
slot = "index/sidebar"
weight = 20

section = "dev/blog"
padding = "px-3" # Experimental. May be removed without notice
summary = false
images = false
display_categories = false
display_date = false
count = 3
+++
