+++
fragment = "content"
weight = 100
#background = ""
categories = ["Sample", "Blog", "Lorem Ipsum"]

title = "First sample blog"
#subtitle = ""
title_align = "left"

display_date = true
date = "2018-07-06"

summary = """
Sometimes you need a **markdown** summary and that's not possible to do with
[Hugo](https://gohugo.io). Lorem ipsum dolor sit amet, consectetur adipiscing
elit. Curabitur a lorem urna.
"""

[sidebar]
  align = "right"

[asset]
  image = "image.png"
+++

I have a 10 year old son. He has words. He is so good with these words it's unbelievable. I write the best placeholder text, and I'm the biggest developer on the web by far... While that's mock-ups and this is politics, are they really so different? He’s not a word hero. He’s a word hero because he was captured. I like text that wasn’t captured. Lorem Ipsum is unattractive, both inside and out. I fully understand why it’s former users left it for something else. They made a good decision.

### You know

You know, it really doesn’t matter what you write as long as you’ve got a young, and beautiful, piece of text. I will write some great placeholder text – and nobody writes better placeholder text than me, believe me – and I’ll write it very inexpensively. I will write some great, great text on your website’s Southern border, and I will make Google pay for that text. Mark my words. Trump Ipsum is calling for a total and complete shutdown of Muslim text entering your website. Despite the constant negative ipsum covfefe.

### Words

All of the words in Lorem Ipsum have flirted with me - consciously or unconsciously. That's to be expected.

Lorem Ipsum is the single greatest threat. We are not - we are not keeping up with other websites.

The other thing with Lorem Ipsum is that you have to take out its family.

That other text? Sadly, it’s no longer a 10. We are going to make placeholder text great again. Greater than ever before.

### Other things

You’re disgusting.

Lorem Ipsum is unattractive, both inside and out. I fully understand why it’s former users left it for something else. They made a good decision. You could see there was text coming out of her eyes, text coming out of her wherever.

I think my strongest asset maybe by far is my temperament. I have a placeholding temperament.

Look at that text! Would anyone use that? Can you imagine that, the text of your next webpage?! I will write some great placeholder text – and nobody writes better placeholder text than me, believe me – and I’ll write it very inexpensively. I will write some great, great text on your website’s Southern border, and I will make Google pay for that text. Mark my words. I was going to say something extremely rough to Lorem Ipsum, to its family, and I said to myself, "I can't do it. I just can't do it. It's inappropriate. It's not nice."
