+++
title = "editor"
fragment = "content"
weight = 100
+++

Different colors for editor fragment
