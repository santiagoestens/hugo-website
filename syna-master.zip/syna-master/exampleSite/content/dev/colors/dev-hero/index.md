+++
title = "hero"
fragment = "content"
weight = 100
+++

Different colors for hero fragment
