+++
fragment = "buttons"
#disabled = false
date = "2016-09-07"
weight = 143
background = "dark"

title = "Buttons Fragment"
subtitle = "Call to action buttons"
#title_align = "left" # Default is center, can be left, right or center

[[buttons]]
  text = "Button"
  url = "#"
  color = "secondary" # primary, secondary, success, danger, warning, info, light, dark, link - default: primary

[[buttons]]
  text = "Long Button"
  url = "#"
  color = "success"

[[buttons]]
  text = "Button"
  url = "#"
  color = "danger"

[[buttons]]
  text = "Button"
  url = "#"
  color = "warning"

[[buttons]]
  text = "Long Button"
  url = "#"
  color = "info"

[[buttons]]
  text = "Button"
  url = "#"
  color = "light"

[[buttons]]
  text = "Button"
  url = "#"
  color = "dark"

[[buttons]]
  text = "Long Button"
  url = "#"
  color = "link"
+++
