+++
fragment = "buttons"
#disabled = false
date = "2016-09-07"
weight = 121
background = "light"

title = "Buttons Fragment Outlined"
subtitle = "Buttons with outlines"
#title_align = "left" # Default is center, can be left, right or center

[[buttons]]
  text = "Button"
  url = "#"
  color = "outline-secondary" # primary, secondary, success, danger, warning, info, light, dark, link - default: primary

[[buttons]]
  text = "Long Button"
  url = "#"
  color = "outline-success"

[[buttons]]
  text = "Button"
  url = "#"
  color = "outline-danger"

[[buttons]]
  text = "Button"
  url = "#"
  color = "outline-warning"

[[buttons]]
  text = "Long Button"
  url = "#"
  color = "outline-info"

[[buttons]]
  text = "Button"
  url = "#"
  color = "outline-light"

[[buttons]]
  text = "Button"
  url = "#"
  color = "outline-dark"

[[buttons]]
  text = "Long Button"
  url = "#"
  color = "outline-link"
+++
