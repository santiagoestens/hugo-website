+++
fragment = "list"
weight = 110
section = "dev/dev-colors"
count = 1000
summary = false
tiled = true
subsections = false
+++
