+++
title = "contact"
fragment = "content"
weight = 100
+++

Different colors for contact fragment
