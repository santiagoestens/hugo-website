+++
title = "header"
fragment = "content"
weight = 100
+++

Different colors for header fragment
