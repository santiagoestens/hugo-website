+++
title = "content"
fragment = "content"
weight = 100
+++

Different colors for content fragment
