+++
fragment = "embed"
#disabled = true
date = "2017-10-07"
weight = 142
background = "secondary"

#title = ""
#subtitle = ""
#title_align = "left" # Default is center, can be left, right or center

# Embed a form via an iframe
# Mailerlite is one example of a working provider.
# There are others such as convertkit.
# Only necessity is for them to use iframes.
media = '<iframe src="https://landing.mailerlite.com/webforms/landing/m0h9d7" style="border: none; width: 100%; height: 178px;"></iframe>'
responsive = false # prevent responsive behaviour
#size = "100" # 25, 50, 75, 100 (percentage) - default: 75
+++
