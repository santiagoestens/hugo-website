+++
fragment = "items"
#disabled = false
date = "2017-10-04"
weight = 141
background = "light"

title = "Items Fragment"
subtitle= "Column based items with icons"
#title_align = "left" # Default is center, can be left, right or center
+++
