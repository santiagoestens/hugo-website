+++
title = "items"
fragment = "content"
weight = 100
+++

Different colors for items fragment
