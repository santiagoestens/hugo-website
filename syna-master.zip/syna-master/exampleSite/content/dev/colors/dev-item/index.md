+++
title = "item"
fragment = "content"
weight = 100
+++

Different colors for item fragment
