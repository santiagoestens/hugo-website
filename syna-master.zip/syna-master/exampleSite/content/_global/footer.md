+++
fragment = "footer"
#disabled = true
date = "2016-09-07"
weight = 1200
background = "secondary"

menu_title = "Further Resources"

[asset]
  image = "logo.svg"
  text = "Logo Subtext"
+++

#### Syna Theme

Highly customizable open source theme for Hugo based static websites
